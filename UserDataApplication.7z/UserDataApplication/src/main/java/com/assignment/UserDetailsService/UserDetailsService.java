package com.assignment.UserDetailsService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.assignment.UserDetailsRepository.UserDetailsRepository;
import com.assignment.model.UserDetails;



@Service
public class UserDetailsService {

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	@Autowired
	UserDetailsRepository userInfoRepo;

	public UserDetails saveUserDetails(UserDetails userReq) {


		UserDetails userInfo = new UserDetails();
		if (userReq != null ) {
			

				userInfo.setName(userReq.getName());
				userInfo.setContact(userReq.getContact());
				userInfo.setEmail(userReq.getEmail());
				userInfo.setPincode(userReq.getPincode());
				userInfo.setDistrict(userReq.getDistrict());
				userInfo.setState(userReq.getState());
				userInfo.setRegion(userReq.getRegion());
				userInfo.setCountry(userReq.getCountry());

				userInfoRepo.save(userInfo);

			}
		

		return userInfo;
	}

	public UserDetails getUserDetailsByEmail(UserDetails userReq) {

		return userInfoRepo.findByEmail(userReq.getEmail());

	}

	public UserDetails getUserDetailsByContact(UserDetails userReq) {

		return userInfoRepo.findByContact(userReq.getContact());

	}

}
