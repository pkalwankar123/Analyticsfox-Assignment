package com.assignment.UserDetailsRepository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.assignment.model.UserDetails;


@Repository
public interface UserDetailsRepository extends JpaRepository<UserDetails, String>{
	
	UserDetails findByEmail(String email);
	UserDetails findByContact(String contact);


}
