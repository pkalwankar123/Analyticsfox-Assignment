package com.assignment.controller;

import java.util.Arrays;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.UserDetailsService.UserDetailsService;
import com.assignment.model.UserDetails;






@RestController
@RequestMapping("/userApp")
public class UserDetailsController {
	
	Log logger = LogFactory.getLog(UserDetailsController.class);

	@Autowired
	UserDetailsService userDetailService;
	

	@PostMapping("/saveUserDetails")
	public ResponseEntity<UserDetails> saveUserDetails(@RequestBody UserDetails userReq){

		logger.info("In saveUserDetails method");
		
		try {
			UserDetails userInfo = userDetailService.saveUserDetails(userReq);
			return new ResponseEntity<>(userInfo, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}}
	
	
	@RequestMapping(value = "/getUserDetailsByPincode")
	   public String getUserDetails() {
	      HttpHeaders headers = new HttpHeaders();
	      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	      HttpEntity <String> entity = new HttpEntity<String>(headers);
	      
	      return userDetailService.restTemplate().exchange("https://api.postalpincode.in/pincode/401105", HttpMethod.GET, entity, String.class).getBody();
	   }


	@GetMapping("/getUserDetailsByEmail")
	public ResponseEntity<UserDetails> getUserDetailsByEmail(@RequestBody UserDetails userReq) {
		logger.info("In getUserDetailsByEmail method");
		
		try {
			UserDetails response=userDetailService.getUserDetailsByEmail(userReq);
				
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
	
		 catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
		
		
	

	@GetMapping("/getUserDetailsByContact")
	public ResponseEntity<UserDetails> getUserDetailsByContact(@RequestBody UserDetails userReq) {
		logger.info("In getUserDetailsByContact method");

			try {
				UserDetails response=userDetailService.getUserDetailsByContact(userReq);
					 
					 return  ResponseEntity.status(HttpStatus.OK).body(response);
				}
		
			 catch (Exception e) {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		
	}



}
